﻿using NUnit.Framework;

using System.Collections.Generic;

namespace TestApp.UnitTests;

public class AdjacentEqualTests
{
    // TODO: finish test
    [Test]
    public void Test_Sum_InputIsEmptyList_ShouldReturnEmptyString()
    {
        // Arrange
            List<int> emptyList = new();

        // Act
        string result = AdjacentEqual.Sum(emptyList);

        // Assert
        Assert.AreEqual(string.Empty, result);
    }

    // TODO: finish test
    [Test]
    public void Test_Sum_NoAdjacentEqualNumbers_ShouldReturnOriginalList()
    {
        // Arrange
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };

        // Act
        string result = AdjacentEqual.Sum(numbers);

        // Assert
        Assert.AreEqual("1 2 3 4 5", result);
    }

    [Test]
    public void Test_Sum_AdjacentEqualNumbersExist_ShouldReturnSummedList()
    {
        // Arrange
        List<int> numbers = new List<int> { 1, 1, 2, 1, 1, 4, 5, 5 };

        // Act
        string result = AdjacentEqual.Sum(numbers);

        // Assert
        Assert.AreEqual("2 2 2 4 10", result);
    }

    [Test]
    public void Test_Sum_AllNumbersAreAdjacentEqual_ShouldReturnSingleSummedNumber()
    {
        // Arrange
        List<int> numbers = new List<int> { 2, 2, 2, 2, 2 };

        // Act
        string result = AdjacentEqual.Sum(numbers);

        // Assert
        Assert.AreEqual("10", result);
    }

    [Test]
    public void Test_Sum_AdjacentEqualNumbersAtBeginning_ShouldReturnSummedList()
    {
        // Arrange
        List<int> numbers = new List<int> { 1, 1, 2, 3, 4, 5 };

        // Act
        string result = AdjacentEqual.Sum(numbers);

        // Assert
        Assert.AreEqual("2 2 3 4 5", result);
    }

    [Test]
    public void Test_Sum_AdjacentEqualNumbersAtEnd_ShouldReturnSummedList()
    {
        // Arrange
        List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 5 };

        // Act
        string result = AdjacentEqual.Sum(numbers);

        // Assert
        Assert.AreEqual("1 2 3 4 10", result);
    }

    [Test]
    public void Test_Sum_AdjacentEqualNumbersInMiddle_ShouldReturnSummedList()
    {
        // Arrange
        List<int> numbers = new List<int> { 1, 2, 2, 2, 3, 4, 5 };

        // Act
        string result = AdjacentEqual.Sum(numbers);

        // Assert
        Assert.AreEqual("1 6 3 4 5", result);
    }
}
