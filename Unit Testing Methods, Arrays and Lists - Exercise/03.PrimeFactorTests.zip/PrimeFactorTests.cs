﻿using NUnit.Framework;

namespace TestApp.UnitTests;

public class PrimeFactorTests
{
    [Test]
    public void Test_FindLargestPrimeFactor_PrimeNumber()
    {
        // Arrange
        long primeNumber = 17;

        // Act
        long largestPrimeFactor = PrimeFactor.FindLargestPrimeFactor(primeNumber);

        // Assert
        Assert.AreEqual(primeNumber, largestPrimeFactor);
    }

    [Test]
    public void Test_FindLargestPrimeFactor_LargeNumber()
    {
        // Arrange
        long largeNumber = 13195;
        long expectedLargestPrimeFactor = 29;

        // Act
        long actualLargestPrimeFactor = PrimeFactor.FindLargestPrimeFactor(largeNumber);

        // Assert
        Assert.AreEqual(expectedLargestPrimeFactor, actualLargestPrimeFactor);
    }
}
