﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace TestApp.Tests;

public class WordEraserTests
{
    [Test]
    public void Test_Erase_EmptyWordsList_ShouldReturnEmptyString()
    {
        WordEraser wEraser = new WordEraser();
        List<string> words = new List<string>();

        // Act
        string actualResult = wEraser.Erase(words, "Exam");

        // Assert
        Assert.AreEqual("", actualResult);
    }

    [Test]
    public void Test_Erase_NullWordsList_ShouldReturnEmptyString()
    {
        WordEraser wEraser = new WordEraser();
        List<string> words = new List<string>();

        // Act
        string actualResult = wEraser.Erase(words, null);

        // Assert
        Assert.AreEqual("", actualResult);
    }

    [Test]
    public void Test_Erase_NullOrEmptyWordToErase_ShouldReturnStringOfGivenWordsList()
    {
        WordEraser wEraser = new WordEraser();
        List<string> words = new List<string> { "Exam1", "Exam2", "Exam3" };

        // Act
        string resultNull = wEraser.Erase(words, null);
        string resultEmpty = wEraser.Erase(words, "");

        // Assert
        Assert.AreEqual("Exam1 Exam2 Exam3", resultNull);
        Assert.AreEqual("Exam1 Exam2 Exam3", resultEmpty);
    }

    [Test]
    public void Test_Erase_ValidInput_ShouldReturnEmptyString_WhenAllWordsMatchedTheWordToErase()
    {
        WordEraser wEraser = new WordEraser();
        List<string> words = new List<string> { "Exam", "Exam", "Exam" };

        // Act
        string actualResult = wEraser.Erase(words, "Exam");

        // Assert
        Assert.AreEqual("", actualResult);
    }

    [Test]
    public void Test_Erase_ValidInput_ShouldReturnStringWithoutErasedWords_WhenFewOfWordsMatchedWordToArese()
    {
        WordEraser wEraser = new WordEraser();
        List<string> words = new List<string> { "Exam1", "Exam2", "Exam3" };

        // Act
        string actualResult = wEraser.Erase(words, "Exam2");

        // Assert
        Assert.AreEqual("Exam1 Exam3", actualResult);
    }
}

