﻿using NUnit.Framework;
using System;

using System.Collections.Generic;

namespace TestApp.Tests;

public class DrumSetTests
{
    [Test]
    public void Test_Drum_TerminateCommandNotGiven_ThrowsArgumentException()
    {
        // Arrange
        decimal money = 1000m;
        List<int> initialQuality = new List<int>()
 {
     10, 20, 30
 };
        List<string> commands = new List<string>()
 {
     "5", "5", "5"
 };

        // Act & Assert
        Assert.Throws<ArgumentException>(() =>
        {
            DrumSet.Drum(money, initialQuality, commands);
        }, "Terminate command not given!");
    }

    [Test]
    public void Test_Drum_StringGivenAsCommand_ThrowsArgumentException()
    {
        // Arrange
        decimal money = 1000m;
        List<int> initialQuality = new List<int>()
        {
            10, 20, 30
        };
        List<string> commands = new List<string>()
        {
            "5", "Pesho", "Hit it again, Gabsy!"
        };

        // Act & Assert
        Assert.Throws<ArgumentException>(() =>
        {
            DrumSet.Drum(money, initialQuality, commands);
        }, "Number did not parse correctly!");
        }

    [Test]
    public void Test_Drum_ReturnsCorrectQualityAndAmount()
    {
        // Arrange
        decimal money = 1000m;
        List<int> initialQuality = new List<int>()
        {
            10, 20, 30
        };
        List<string> commands = new List<string>()
        {
            "5", "5", "15", "Hit it again, Gabsy!", "5"
        };
        string expectedResult = $"10 20 5\nGabsy has 880.00lv.";

        // Act
        string actualResult = DrumSet.Drum(money, initialQuality, commands);

        Assert.AreEqual(expectedResult, actualResult);
    }

    [Test]
    public void Test_Drum_BalanceZero_WithOneDrumLeftOver_ReturnsCorrectQualityAndAmount()
    {
        // Arrange
        decimal money = 0m;
        List<int> initialQuality = new List<int>() { 10, 20, 30 };
        List<string> commands = new List<string>() { "5", "5", "15", "Hit it again, Gabsy!", "5" };
        string expectedResult = $"5\nGabsy has 0.00lv.";

        // Act
        string actualResult = DrumSet.Drum(money, initialQuality, commands);

        // Assert
        Assert.AreEqual(expectedResult, actualResult);
    }

        [Test]
    public void Test_Drum_NotEnoughBalance_RemovesAllDrums_ReturnsCorrectQualityAndAmount()
    {
        // Arrange
        decimal money = 0m;
        List<int> initialQuality = new List<int>() { 5 };
        List<string> commands = new List<string>() { "5", "Hit it again, Gabsy!" };

        string expectedResult = $"\nGabsy has 0.00lv.";

        // Act
        string actualResult = DrumSet.Drum(money, initialQuality, commands);

        // Assert
        Assert.AreEqual(expectedResult, actualResult);
    }
}