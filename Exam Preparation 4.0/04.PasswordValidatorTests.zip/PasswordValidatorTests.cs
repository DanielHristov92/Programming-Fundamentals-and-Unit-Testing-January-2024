﻿using NUnit.Framework;

namespace TestApp.Tests
{
    public class PasswordValidatorTests
    {
        [Test]
        public void Test_CheckPassword_ValidPassword_ReturnsValidMessage()
        {
            // Arrange
            string password = "Pass123";

            // Act
            string result = PasswordValidator.CheckPassword(password);

            // Assert
            Assert.AreEqual("Password is valid", result);
        }

        [Test]
        public void Test_CheckPassword_PasswordTooShort_ReturnsErrorMessage()
        {
            // Arrange
            string password = "Short";

            // Act
            string result = PasswordValidator.CheckPassword(password);

            // Assert
            Assert.AreEqual("Password must be between 6 and 10 characters", result);
        }

        [Test]
        public void Test_CheckPassword_ContainsSpecialCharacters_ReturnsErrorMessage()
        {
            // Arrange
            string password = "Inv@Pass";

            // Act
            string result = PasswordValidator.CheckPassword(password);

            // Assert
            Assert.AreEqual("Password must consist only of letters and digits", result);
        }

        [Test]
        public void Test_CheckPassword_InsufficientDigits_ReturnsErrorMessage()
        {
            // Arrange
            string password = "NoDigits";

            // Act
            string result = PasswordValidator.CheckPassword(password);

            // Assert
            Assert.AreEqual("Password must have at least 2 digits", result);
        }

        [Test]
        public void Test_CheckPassword_ValidPasswordWithMaximumLength_ReturnsValidMessage()
        {
            // Arrange
            string password = "ValPass123";

            // Act
            string result = PasswordValidator.CheckPassword(password);

            // Assert
            Assert.AreEqual("Password is valid", result);
        }
    }
}
