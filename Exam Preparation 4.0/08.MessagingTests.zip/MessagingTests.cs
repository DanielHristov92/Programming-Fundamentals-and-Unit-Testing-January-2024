﻿using NUnit.Framework;
using System.Collections.Generic;

namespace TestApp.Tests
{
    public class MessagingTests
    {
        [Test]
        public void Test_GetMessage_WithValidInput_ReturnsExpectedMessage()
        {
            // Arrange
            List<int> nums = new List<int> { 123, 456 };
            string s = "abcde";

            // Act
            string result = Messaging.GetMessage(nums, s);

            // Assert
            Assert.AreEqual("be", result);
        }

            [Test]
        public void Test_GetMessage_EmptyList_ReturnsEmptyString()
        {
            // Arrange
            List<int> nums = new List<int>();
            string s = "abcde";

            // Act
            string result = Messaging.GetMessage(nums, s);

            // Assert
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void Test_GetMessage_EmptyString_ReturnsEmptyString()
        {
            // Arrange
            List<int> nums = new List<int> { 123, 456 };
            string s = "";

            // Act
            string result = Messaging.GetMessage(nums, s);

            // Assert
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void Test_GetMessage_NullList_ReturnsEmptyString()
        {
            // Arrange
            List<int>? nums = null;
            string s = "abcde";

            // Act
            string result = Messaging.GetMessage(nums, s);

            // Assert
            Assert.AreEqual(string.Empty, result);
        }

        [Test]
        public void Test_GetMessage_NullString_ReturnsEmptyString()
        {
            // Arrange
            List<int> nums = new List<int> { 123, 456 };
            string? s = null;

            // Act
            string result = Messaging.GetMessage(nums, s);

            // Assert
            Assert.AreEqual(string.Empty, result);
        }
    }
}
